// Camara Vision
//
// Copyright � Andrew Kirillov, 2005-2006
// andrew.kirillov@gmail.com
//

namespace videosource
{
	using System;

	// stream types
	public enum StreamType
	{
		Jpeg,
		MJpeg
	}
}
