
class Client
	def appendText(t_1,t_2)
		return t_1<<t_2
	end
end